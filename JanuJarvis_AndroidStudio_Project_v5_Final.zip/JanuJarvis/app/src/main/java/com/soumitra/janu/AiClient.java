package com.soumitra.janu;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Talks to Gemini (key 1, then key 2 as automatic backup) and then to an optional
 * OpenAI-compatible custom API. First provider that answers wins -> fast + reliable.
 */
final class AiClient {
    private AiClient() {}

    static final String[] FALLBACK_MODELS = {"gemini-flash-lite-latest", "gemini-flash-latest"};

    static final class HttpErr extends IOException {
        final int code;
        HttpErr(int code, String msg) { super(msg); this.code = code; }
    }

    static final class VerifyResult {
        boolean ok;
        long ms;
        String msg;
    }

    // ---------------------------------------------------------------- public API

    static String ask(Context c, String system, List<String[]> hist, String user) throws Exception {
        String lastErr = null;
        int tried = 0;
        for (int slot = 1; slot <= 2; slot++) {
            String key = Prefs.geminiKey(c, slot);
            if (key.isEmpty()) continue;
            tried++;
            try {
                return gemini(c, key, system, hist, user, 600);
            } catch (Exception e) {
                lastErr = e.getMessage();
            }
        }
        String ck = Prefs.customKey(c);
        if (!ck.isEmpty()) {
            tried++;
            try {
                return openAi(Prefs.customUrl(c), ck, Prefs.customModel(c), system, hist, user, 600);
            } catch (Exception e) {
                lastErr = e.getMessage();
            }
        }
        if (tried == 0) throw new Exception("NO_KEY");
        throw new Exception(lastErr == null ? "API error" : lastErr);
    }

    static VerifyResult verifyGemini(Context c, String key) {
        VerifyResult r = new VerifyResult();
        long t = System.currentTimeMillis();
        try {
            gemini(c, key, "Reply with exactly this JSON: {\"ok\":true}", new ArrayList<String[]>(), "ping", 16);
            r.ok = true;
        } catch (Exception e) {
            r.msg = e.getMessage();
        }
        r.ms = System.currentTimeMillis() - t;
        return r;
    }

    static VerifyResult verifyCustom(String url, String key, String model) {
        VerifyResult r = new VerifyResult();
        long t = System.currentTimeMillis();
        try {
            openAi(url, key, model, "Reply with exactly this JSON: {\"ok\":true}", new ArrayList<String[]>(), "ping", 16);
            r.ok = true;
        } catch (Exception e) {
            r.msg = e.getMessage();
        }
        r.ms = System.currentTimeMillis() - t;
        return r;
    }

    // ---------------------------------------------------------------- prompt

    static String system(Context c, VoiceProfile vp) {
        boolean hi = Prefs.hindi(c);
        String language = hi
                ? "Hindi written in Devanagari script (English words like app names may stay in Latin letters). Use simple spoken Hindi."
                : "simple spoken English.";
        return "You are JANU, a voice assistant that lives inside the user's Android phone and controls it, like Jarvis. "
            + "Personality: " + vp.persona + "\n"
            + "The user's words come from speech-to-text, so names may be spelled phonetically (e.g. 'honey singh' means Yo Yo Honey Singh). Fix such mistakes sensibly.\n"
            + "Reply language: " + language + "\n"
            + "Current local date and time: " + new SimpleDateFormat("EEEE, d MMMM yyyy, HH:mm (hh:mm a)", Locale.ENGLISH).format(new Date())
            + ". If asked the time, date or day, answer it directly and naturally in the reply (spoken style, e.g. 'अभी रात के साढ़े ग्यारह बजे हैं बाबू').\n"
            + "Answer with ONLY one JSON object (no markdown, no code fences):\n"
            + "{\"reply\":\"...\",\"actions\":[...]}\n"
            + "\"reply\" is spoken aloud: max 2 short, soft, loving sentences, no emojis, no markdown. Stay fully in your girlfriend personality and address the user as Babu/Sona/Boss, never 'Sir'. If he sounds sad, tired or stressed, comfort him first with real warmth.\n"
            + "\"actions\" is an ordered list (empty for plain chat/questions). Allowed actions:\n"
            + " {\"type\":\"open_app\",\"app\":\"app name\"}\n"
            + " {\"type\":\"open_tool\",\"tool\":\"creator|drawing\"}\n"
            + " {\"type\":\"youtube_play\",\"query\":\"artist + song or video to search and auto-play\"}\n"
            + " {\"type\":\"youtube_search\",\"query\":\"...\"}\n"
            + " {\"type\":\"search_in_app\",\"app\":\"facebook|instagram|whatsapp|youtube|other app name\",\"query\":\"person/page/text to search\"}\n"
            + " {\"type\":\"whatsapp_message\",\"contact\":\"name in Latin letters or phone number\",\"text\":\"message\"}\n"
            + " {\"type\":\"whatsapp_call\",\"contact\":\"name in Latin letters or phone number\"}\n"
            + " {\"type\":\"send_sms\",\"contact\":\"...\",\"text\":\"...\"}\n"
            + " {\"type\":\"call\",\"contact\":\"...\"}\n"
            + " {\"type\":\"comment\",\"text\":\"comment to post on the post/video currently on screen\"}\n"
            + " {\"type\":\"like\"}\n"
            + " {\"type\":\"scroll\",\"direction\":\"down|up\"}   (down = next reel/short/feed item)\n"
            + " {\"type\":\"click\",\"label\":\"visible text or description of a button on screen\"}\n"
            + " {\"type\":\"type_text\",\"text\":\"...\"}\n"
            + " {\"type\":\"back\"}  {\"type\":\"home\"}  {\"type\":\"recents\"}\n"
            + " {\"type\":\"web_search\",\"query\":\"...\"}  {\"type\":\"open_url\",\"url\":\"https://...\"}\n"
            + " {\"type\":\"set_alarm\",\"hour\":7,\"minute\":30,\"label\":\"optional\"}   (24-hour clock; work out the hour/minute from the current time, e.g. 'सुबह 6 बजे' = 6:00, 'शाम 5 बजे' = 17:00)\n"
            + " {\"type\":\"set_timer\",\"seconds\":300,\"label\":\"optional\"}\n"
            + " {\"type\":\"look_at_screen\",\"question\":\"what the user wants to know about the screen\"}   (use when he says 'meri screen dekho', 'ye kya hai', 'screen pe kya likha hai', 'isko padho/samjhao'. Reply only a short 'ठीक है बाबू, देखती हूँ'; the screen answer is spoken afterwards.)\n"
            + " {\"type\":\"wait\",\"seconds\":2}\n"
            + "Rules:\n"
            + "- Song/video requests: use youtube_play with the best query (e.g. \"Yo Yo Honey Singh songs\").\n"
            + "- Always write contact names in Latin letters (transliterate Hindi names, e.g. Golu).\n"
            + "- If the user does not give exact message/comment text, compose a short suitable one yourself.\n"
            + "- For multi-step requests put the actions in order (e.g. open_app, then search_in_app).\n"
            + "- Use the fewest actions needed. Never claim to have done something you have no action for; say so politely with empty actions.\n"
            + "- Only ask a question (with empty actions) when essential info is truly missing.\n"
            + "- To type into a search box in any app (e.g. Play Store): open_app, then search_in_app with that app name and the query.\n"
            + "- If the user says drawing/draw/sketch/ड्राइंग बनाना है, use open_tool with tool=drawing. If the user says create studio/creative studio, use open_tool with tool=creator.\n"
            + "- If the user asks to call someone on WhatsApp, use whatsapp_call. Prefer WhatsApp Business when it is installed.\n";
    }

    // ---------------------------------------------------------------- screen understanding

    static String visionSystem(Context c, VoiceProfile vp) {
        boolean hi = Prefs.hindi(c);
        return "You are JANU, the user's phone assistant. Personality: " + vp.persona + "\n"
            + "You are shown a screenshot of the user's phone screen right now. Answer his question about it in "
            + (hi ? "simple spoken Hindi (Devanagari; app names may stay in English)" : "simple spoken English")
            + ". Plain spoken text only: no JSON, no markdown, no emojis, no lists. Max 3 short sentences, soft and loving, "
            + "address him as Babu/Sona/Boss. Read out the important on-screen text if he asks. "
            + "If the screen shows passwords, OTPs or card numbers, do not read them out; just say they are there.";
    }

    /** Sends a screenshot (JPEG, base64) plus a question to Gemini (key 1, key 2) and then to the custom API. */
    static String askAboutImage(Context c, String system, String question, String jpegB64) throws Exception {
        String lastErr = null;
        for (int slot = 1; slot <= 2; slot++) {
            String key = Prefs.geminiKey(c, slot);
            if (key.isEmpty()) continue;
            List<String> models = new ArrayList<>();
            models.add(Prefs.model(c));
            for (String m : FALLBACK_MODELS) if (!models.contains(m)) models.add(m);
            for (String m : models) {
                try {
                    return geminiVision(key, m, system, question, jpegB64);
                } catch (HttpErr e) {
                    lastErr = e.getMessage();
                    if (e.code == 404 || e.code == 503) continue;
                    break;
                } catch (Exception e) {
                    lastErr = e.getMessage();
                    break;
                }
            }
        }
        String ck = Prefs.customKey(c);
        if (!ck.isEmpty()) {
            try { return openAiVision(Prefs.customUrl(c), ck, Prefs.customModel(c), system, question, jpegB64); }
            catch (Exception e) { lastErr = e.getMessage(); }
        }
        throw new Exception(lastErr == null ? "NO_KEY" : lastErr);
    }

    private static String geminiVision(String key, String model, String system, String question, String b64) throws Exception {
        JSONObject body = new JSONObject();
        body.put("systemInstruction", new JSONObject().put("parts", new JSONArray().put(new JSONObject().put("text", system))));
        JSONArray parts = new JSONArray()
                .put(new JSONObject().put("inline_data", new JSONObject().put("mime_type", "image/jpeg").put("data", b64)))
                .put(new JSONObject().put("text", question));
        body.put("contents", new JSONArray().put(new JSONObject().put("role", "user").put("parts", parts)));
        body.put("generationConfig", new JSONObject().put("temperature", 0.6).put("maxOutputTokens", 500));
        String url = "https://generativelanguage.googleapis.com/v1beta/models/" + model + ":generateContent";
        String resp = post(url, new String[][]{{"x-goog-api-key", key}}, body.toString());
        JSONArray cand = new JSONObject(resp).optJSONArray("candidates");
        if (cand == null || cand.length() == 0) throw new Exception("Gemini: empty answer");
        JSONObject content = cand.getJSONObject(0).optJSONObject("content");
        if (content == null) throw new Exception("Gemini: blocked/empty answer");
        JSONArray ps = content.optJSONArray("parts");
        StringBuilder sb = new StringBuilder();
        if (ps != null) for (int i = 0; i < ps.length(); i++) sb.append(ps.getJSONObject(i).optString("text"));
        return sb.toString();
    }

    private static String openAiVision(String baseUrl, String key, String model, String system, String question, String b64) throws Exception {
        String base = baseUrl.trim();
        while (base.endsWith("/")) base = base.substring(0, base.length() - 1);
        JSONArray userParts = new JSONArray()
                .put(new JSONObject().put("type", "text").put("text", question))
                .put(new JSONObject().put("type", "image_url").put("image_url",
                        new JSONObject().put("url", "data:image/jpeg;base64," + b64)));
        JSONArray msgs = new JSONArray()
                .put(new JSONObject().put("role", "system").put("content", system))
                .put(new JSONObject().put("role", "user").put("content", userParts));
        JSONObject body = new JSONObject().put("model", model).put("messages", msgs).put("max_tokens", 500);
        String resp = post(base + "/chat/completions", new String[][]{{"Authorization", "Bearer " + key}}, body.toString());
        JSONArray ch = new JSONObject(resp).optJSONArray("choices");
        if (ch == null || ch.length() == 0) throw new Exception("Custom API: empty answer");
        return ch.getJSONObject(0).getJSONObject("message").optString("content");
    }

    // ---------------------------------------------------------------- Gemini

    private static String gemini(Context c, String key, String system, List<String[]> hist,
                                 String user, int maxTokens) throws Exception {
        List<String> models = new ArrayList<>();
        models.add(Prefs.model(c));
        for (String m : FALLBACK_MODELS) if (!models.contains(m)) models.add(m);
        Exception last = null;
        for (String m : models) {
            try {
                return geminiCall(key, m, system, hist, user, maxTokens);
            } catch (HttpErr e) {
                last = e;
                if (e.code == 404 || e.code == 503) continue; // model retired / overloaded -> next model
                throw e;
            }
        }
        throw last == null ? new Exception("Gemini error") : last;
    }

    private static String geminiCall(String key, String model, String system, List<String[]> hist,
                                     String user, int maxTokens) throws Exception {
        JSONObject body = new JSONObject();
        body.put("systemInstruction", new JSONObject().put("parts",
                new JSONArray().put(new JSONObject().put("text", system))));
        JSONArray contents = new JSONArray();
        for (String[] h : hist) {
            contents.put(new JSONObject()
                    .put("role", h[0].equals("user") ? "user" : "model")
                    .put("parts", new JSONArray().put(new JSONObject().put("text", h[1]))));
        }
        contents.put(new JSONObject().put("role", "user")
                .put("parts", new JSONArray().put(new JSONObject().put("text", user))));
        body.put("contents", contents);
        body.put("generationConfig", new JSONObject()
                .put("temperature", 0.7)
                .put("maxOutputTokens", maxTokens)
                .put("responseMimeType", "application/json"));

        String url = "https://generativelanguage.googleapis.com/v1beta/models/" + model + ":generateContent";
        String resp = post(url, new String[][]{{"x-goog-api-key", key}}, body.toString());
        JSONObject o = new JSONObject(resp);
        JSONArray cand = o.optJSONArray("candidates");
        if (cand == null || cand.length() == 0) throw new Exception("Gemini: empty answer");
        JSONObject content = cand.getJSONObject(0).optJSONObject("content");
        if (content == null) throw new Exception("Gemini: blocked/empty answer");
        JSONArray parts = content.optJSONArray("parts");
        StringBuilder sb = new StringBuilder();
        if (parts != null) for (int i = 0; i < parts.length(); i++) sb.append(parts.getJSONObject(i).optString("text"));
        return sb.toString();
    }

    // ---------------------------------------------------------------- OpenAI-compatible

    private static String openAi(String baseUrl, String key, String model, String system,
                                 List<String[]> hist, String user, int maxTokens) throws Exception {
        String base = baseUrl.trim();
        while (base.endsWith("/")) base = base.substring(0, base.length() - 1);
        JSONArray msgs = new JSONArray();
        msgs.put(new JSONObject().put("role", "system").put("content", system));
        for (String[] h : hist) {
            msgs.put(new JSONObject().put("role", h[0].equals("user") ? "user" : "assistant").put("content", h[1]));
        }
        msgs.put(new JSONObject().put("role", "user").put("content", user));
        JSONObject body = new JSONObject().put("model", model).put("messages", msgs)
                .put("temperature", 0.7).put("max_tokens", maxTokens);
        String resp = post(base + "/chat/completions",
                new String[][]{{"Authorization", "Bearer " + key}}, body.toString());
        JSONArray ch = new JSONObject(resp).optJSONArray("choices");
        if (ch == null || ch.length() == 0) throw new Exception("Custom API: empty answer");
        return ch.getJSONObject(0).getJSONObject("message").optString("content");
    }

    // ---------------------------------------------------------------- HTTP

    private static String post(String urlStr, String[][] headers, String body) throws IOException {
        HttpURLConnection con = (HttpURLConnection) new URL(urlStr).openConnection();
        try {
            con.setRequestMethod("POST");
            con.setConnectTimeout(8000);
            con.setReadTimeout(25000);
            con.setDoOutput(true);
            con.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            for (String[] h : headers) con.setRequestProperty(h[0], h[1]);
            byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
            con.setFixedLengthStreamingMode(bytes.length);
            try (OutputStream os = con.getOutputStream()) { os.write(bytes); }
            int code = con.getResponseCode();
            InputStream is = code >= 400 ? con.getErrorStream() : con.getInputStream();
            String text = is == null ? "" : readAll(is);
            if (code >= 400) throw new HttpErr(code, "HTTP " + code + ": " + errorMessage(text));
            return text;
        } finally {
            con.disconnect();
        }
    }

    private static String errorMessage(String text) {
        try {
            JSONObject e = new JSONObject(text).optJSONObject("error");
            if (e != null) return e.optString("message", text);
        } catch (Exception ignored) { }
        return text.length() > 160 ? text.substring(0, 160) : text;
    }

    private static String readAll(InputStream is) throws IOException {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[4096];
        int n;
        while ((n = is.read(buf)) > 0) bo.write(buf, 0, n);
        return bo.toString("UTF-8");
    }
}
