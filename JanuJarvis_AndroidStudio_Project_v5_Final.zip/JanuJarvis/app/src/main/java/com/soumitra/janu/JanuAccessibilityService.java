package com.soumitra.janu;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.ColorSpace;
import android.graphics.Path;
import android.graphics.Rect;
import android.os.Build;
import android.os.Bundle;
import android.hardware.HardwareBuffer;
import android.util.Base64;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.io.ByteArrayOutputStream;
import java.util.Locale;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Lets Janu tap, type, scroll and press back/home inside other apps.
 * All helpers are meant to be called from a background thread (they sleep while polling).
 */
public class JanuAccessibilityService extends AccessibilityService {

    private static volatile JanuAccessibilityService inst;

    static JanuAccessibilityService get() { return inst; }

    @Override protected void onServiceConnected() { super.onServiceConnected(); inst = this; }
    @Override public boolean onUnbind(android.content.Intent i) { inst = null; return super.onUnbind(i); }
    @Override public void onDestroy() { inst = null; super.onDestroy(); }
    @Override public void onAccessibilityEvent(AccessibilityEvent event) { /* polling based */ }
    @Override public void onInterrupt() { }

    // ------------------------------------------------------------ helpers

    private static void sleep(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
    }

    String currentPackage() {
        AccessibilityNodeInfo r = getRootInActiveWindow();
        return (r == null || r.getPackageName() == null) ? "" : r.getPackageName().toString();
    }

    boolean waitForPackage(String pkg, long timeoutMs) {
        long end = System.currentTimeMillis() + timeoutMs;
        while (System.currentTimeMillis() < end) {
            if (pkg.equals(currentPackage())) return true;
            sleep(250);
        }
        return false;
    }

    private AccessibilityNodeInfo find(AccessibilityNodeInfo n, String label, boolean exact, int depth) {
        if (n == null || depth > 60) return null;
        if (n.isVisibleToUser() && !n.isEditable()) {
            CharSequence tx = n.getText(), ds = n.getContentDescription();
            if (matches(tx, label, exact) || matches(ds, label, exact)) return n;
        }
        for (int i = 0; i < n.getChildCount(); i++) {
            AccessibilityNodeInfo hit = find(n.getChild(i), label, exact, depth + 1);
            if (hit != null) return hit;
        }
        return null;
    }

    private static boolean matches(CharSequence s, String label, boolean exact) {
        if (s == null || s.length() == 0) return false;
        String a = s.toString().trim().toLowerCase(Locale.ROOT);
        String b = label.trim().toLowerCase(Locale.ROOT);
        return exact ? a.equals(b) : a.contains(b);
    }

    private boolean clickNode(AccessibilityNodeInfo n) {
        AccessibilityNodeInfo cur = n;
        for (int i = 0; i < 7 && cur != null; i++) {
            if (cur.isClickable() && cur.isEnabled() && cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true;
            cur = cur.getParent();
        }
        Rect b = new Rect();
        n.getBoundsInScreen(b);
        return b.width() > 0 && tap(b.centerX(), b.centerY());
    }

    /** Exact matches first (for all labels), then "contains" matches. */
    boolean clickLabel(String... labels) {
        AccessibilityNodeInfo r = getRootInActiveWindow();
        if (r == null) return false;
        for (String l : labels) { AccessibilityNodeInfo n = find(r, l, true, 0); if (n != null) return clickNode(n); }
        for (String l : labels) { AccessibilityNodeInfo n = find(r, l, false, 0); if (n != null) return clickNode(n); }
        return false;
    }

    boolean waitClick(long timeoutMs, String... labels) {
        long end = System.currentTimeMillis() + timeoutMs;
        do {
            if (clickLabel(labels)) return true;
            sleep(350);
        } while (System.currentTimeMillis() < end);
        return false;
    }

    private AccessibilityNodeInfo findEditable(AccessibilityNodeInfo n, int depth) {
        if (n == null || depth > 60) return null;
        if (n.isEditable() && n.isVisibleToUser()) return n;
        for (int i = 0; i < n.getChildCount(); i++) {
            AccessibilityNodeInfo hit = findEditable(n.getChild(i), depth + 1);
            if (hit != null) return hit;
        }
        return null;
    }

    /** Finds the text field: focused one first, then any editable in any visible window. */
    private AccessibilityNodeInfo findInputField() {
        AccessibilityNodeInfo r = getRootInActiveWindow();
        if (r != null) {
            AccessibilityNodeInfo e = r.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
            if (e != null && e.isEditable()) return e;
            e = findEditable(r, 0);
            if (e != null) return e;
        }
        try {
            for (android.view.accessibility.AccessibilityWindowInfo w : getWindows()) {
                AccessibilityNodeInfo root = w.getRoot();
                AccessibilityNodeInfo e = root == null ? null : findEditable(root, 0);
                if (e != null) return e;
            }
        } catch (Exception ignored) { }
        return null;
    }

    boolean setText(String text) {
        AccessibilityNodeInfo e = findInputField();
        if (e == null) return false;
        e.performAction(AccessibilityNodeInfo.ACTION_FOCUS);
        e.performAction(AccessibilityNodeInfo.ACTION_CLICK);
        sleep(150);
        Bundle b = new Bundle();
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text);
        if (e.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)) {
            sleep(120);
            e.refresh();
            CharSequence now = e.getText();
            if (now != null && now.toString().contains(text)) return true;
        }
        // Fallback: paste through the clipboard (works in fields that refuse SET_TEXT).
        try {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("janu", text));
            e.performAction(AccessibilityNodeInfo.ACTION_FOCUS);
            Bundle sel = new Bundle();
            sel.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, 0);
            sel.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, e.getText() == null ? 0 : e.getText().length());
            e.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, sel);
            return e.performAction(AccessibilityNodeInfo.ACTION_PASTE);
        } catch (Exception ex) {
            return false;
        }
    }

    boolean waitSetText(long timeoutMs, String text) {
        long end = System.currentTimeMillis() + timeoutMs;
        do {
            if (setText(text)) return true;
            sleep(350);
        } while (System.currentTimeMillis() < end);
        return false;
    }

    /** Presses the keyboard's Enter/Search key on the focused field (Android 11+). */
    boolean pressEnter() {
        if (Build.VERSION.SDK_INT < 30) return false;
        AccessibilityNodeInfo e = findInputField();
        return e != null && e.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.getId());
    }

    boolean tap(float x, float y) {
        Path path = new Path();
        path.moveTo(x, y);
        GestureDescription.StrokeDescription s = new GestureDescription.StrokeDescription(path, 0, 60);
        return dispatchGesture(new GestureDescription.Builder().addStroke(s).build(), null, null);
    }

    /** Swipe using screen fractions (0..1). */
    boolean swipe(float x1, float y1, float x2, float y2, long durMs) {
        DisplayMetrics m = getResources().getDisplayMetrics();
        Path path = new Path();
        path.moveTo(m.widthPixels * x1, m.heightPixels * y1);
        path.lineTo(m.widthPixels * x2, m.heightPixels * y2);
        GestureDescription.StrokeDescription s = new GestureDescription.StrokeDescription(path, 0, durMs);
        return dispatchGesture(new GestureDescription.Builder().addStroke(s).build(), null, null);
    }

    /** Screenshot of what is on screen right now (Android 11+), as a downscaled JPEG in base64. Null if impossible. */
    String screenshotJpegBase64() {
        if (Build.VERSION.SDK_INT < 30) return null;
        final CountDownLatch latch = new CountDownLatch(1);
        final AtomicReference<Bitmap> out = new AtomicReference<>();
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, getMainExecutor(), new TakeScreenshotCallback() {
                @Override public void onSuccess(ScreenshotResult result) {
                    try {
                        HardwareBuffer hb = result.getHardwareBuffer();
                        ColorSpace cs = result.getColorSpace();
                        Bitmap hw = Bitmap.wrapHardwareBuffer(hb, cs);
                        if (hw != null) out.set(hw.copy(Bitmap.Config.ARGB_8888, false));
                        hb.close();
                    } catch (Throwable ignored) { }
                    latch.countDown();
                }
                @Override public void onFailure(int errorCode) { latch.countDown(); }
            });
            if (!latch.await(6, TimeUnit.SECONDS)) return null;
        } catch (Throwable t) {
            return null;
        }
        Bitmap bmp = out.get();
        if (bmp == null) return null;
        int max = 1080, w = bmp.getWidth(), h = bmp.getHeight();
        float sc = Math.min(1f, (float) max / Math.max(w, h));
        if (sc < 1f) bmp = Bitmap.createScaledBitmap(bmp, Math.round(w * sc), Math.round(h * sc), true);
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.JPEG, 70, bo);
        return Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP);
    }

    void back() { performGlobalAction(GLOBAL_ACTION_BACK); }
    void home() { performGlobalAction(GLOBAL_ACTION_HOME); }
    void recents() { performGlobalAction(GLOBAL_ACTION_RECENTS); }
}
