package com.soumitra.janu;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class DrawingActivity extends Activity {
    private DrawingView canvas;
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_drawing);
        canvas = findViewById(R.id.drawingCanvas);
        findViewById(R.id.btnClear).setOnClickListener(v -> canvas.clear());
        findViewById(R.id.btnUndo).setOnClickListener(v -> canvas.undo());
        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
    }
}
