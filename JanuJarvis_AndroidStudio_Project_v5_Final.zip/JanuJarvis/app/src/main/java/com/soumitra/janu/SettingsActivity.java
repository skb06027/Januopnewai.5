package com.soumitra.janu;

import android.Manifest;
import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class SettingsActivity extends Activity {

    private static final String[] MODEL_LABELS = {"⚡ Ultra Fast — Flash-Lite (recommended)", "🧠 Smarter — Flash", "✏ Custom model ID"};
    private static final String[] MODEL_IDS = {"gemini-flash-lite-latest", "gemini-flash-latest", ""};
    private static final String[] LANG_LABELS = {"हिन्दी / Hinglish (hi-IN)", "English (en-IN)"};
    private static final String[] LANG_IDS = {"hi-IN", "en-IN"};

    private EditText etKey1, etKey2, etModel, etUrl, etCKey, etCModel;
    private TextView tvV1, tvV2, tvVC;
    private Spinner spModel, spLang;
    private Switch swWake;
    private LinearLayout permList, voiceList;
    private OrbView orbPreview;
    private final List<TextView> voiceChips = new ArrayList<>();
    private String err1, err2, errC; // last verify errors
    private boolean loading = true;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_settings);
        etKey1 = findViewById(R.id.etKey1); etKey2 = findViewById(R.id.etKey2); etModel = findViewById(R.id.etModel);
        etUrl = findViewById(R.id.etUrl); etCKey = findViewById(R.id.etCKey); etCModel = findViewById(R.id.etCModel);
        tvV1 = findViewById(R.id.tvVerify1); tvV2 = findViewById(R.id.tvVerify2); tvVC = findViewById(R.id.tvVerifyC);
        spModel = findViewById(R.id.spModel); spLang = findViewById(R.id.spLang);
        swWake = findViewById(R.id.swWake); permList = findViewById(R.id.permList);
        voiceList = findViewById(R.id.voiceList); orbPreview = findViewById(R.id.orbPreview);
        orbPreview.setColorNow(VoiceProfile.ALL[Prefs.voice(this)].color);
        buildVoiceList();

        spModel.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, MODEL_LABELS));
        spLang.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, LANG_LABELS));

        etKey1.setText(Prefs.geminiKey(this, 1));
        etKey2.setText(Prefs.geminiKey(this, 2));
        etUrl.setText(Prefs.customUrl(this));
        etCKey.setText(Prefs.customKey(this));
        etCModel.setText(Prefs.customModel(this));
        swWake.setChecked(Prefs.wake(this));

        String m = Prefs.model(this);
        int mi = 2;
        for (int i = 0; i < 2; i++) if (MODEL_IDS[i].equals(m)) mi = i;
        spModel.setSelection(mi);
        if (mi == 2) { etModel.setText(m); etModel.setVisibility(View.VISIBLE); }
        spLang.setSelection(Prefs.hindi(this) ? 0 : 1);

        spModel.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> p, View v, int pos, long id) {
                etModel.setVisibility(pos == 2 ? View.VISIBLE : View.GONE);
            }
            @Override public void onNothingSelected(AdapterView<?> p) { }
        });

        findViewById(R.id.btnVerify1).setOnClickListener(v -> verifyGemini(1));
        findViewById(R.id.btnVerify2).setOnClickListener(v -> verifyGemini(2));
        findViewById(R.id.btnVerifyC).setOnClickListener(v -> verifyCustom());
        findViewById(R.id.btnTts).setOnClickListener(v -> {
            try { startActivity(new Intent("com.android.settings.TTS_SETTINGS")); }
            catch (Exception e) { startActivity(new Intent(Settings.ACTION_SETTINGS)); }
        });
        findViewById(R.id.btnGrantAll).setOnClickListener(v -> {
            List<String> need = missingRuntime();
            if (need.isEmpty()) Toast.makeText(this, "Saari runtime permissions mil chuki hain ✔", Toast.LENGTH_SHORT).show();
            else requestPermissions(need.toArray(new String[0]), 1);
        });
        findViewById(R.id.btnStop).setOnClickListener(v -> {
            startService(new Intent(this, JanuService.class).setAction(JanuService.A_STOP));
            Toast.makeText(this, "Janu band ho gaya", Toast.LENGTH_SHORT).show();
        });
        loading = false;
        renderVerify();
    }

    @Override protected void onResume() { super.onResume(); buildPermissions(); }

    // ------------------------------------------------------------------ voices

    private void buildVoiceList() {
        voiceList.removeAllViews();
        voiceChips.clear();
        for (int i = 0; i < VoiceProfile.ALL.length; i++) {
            final int idx = i;
            TextView tv = new TextView(this);
            tv.setText(VoiceProfile.ALL[i].emoji + "  " + VoiceProfile.ALL[i].name);
            tv.setTextSize(15);
            tv.setGravity(Gravity.CENTER_VERTICAL);
            tv.setPadding(dp(16), dp(12), dp(16), dp(12));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.setMargins(0, dp(4), 0, dp(4));
            tv.setLayoutParams(lp);
            tv.setOnClickListener(v -> chooseVoice(idx));
            voiceList.addView(tv);
            voiceChips.add(tv);
        }
        paintVoices();
    }

    private void paintVoices() {
        int sel = Prefs.voice(this);
        for (int i = 0; i < voiceChips.size(); i++) {
            VoiceProfile vp = VoiceProfile.ALL[i];
            GradientDrawable g = new GradientDrawable();
            g.setCornerRadius(dp(14));
            if (i == sel) {
                g.setColor((vp.color & 0x00FFFFFF) | 0x55000000);
                g.setStroke(dp(2), vp.color);
                voiceChips.get(i).setTextColor(Color.WHITE);
            } else {
                g.setColor(0x66101018);
                g.setStroke(dp(1), 0x44FFFFFF);
                voiceChips.get(i).setTextColor(0xFFC9C9DD);
            }
            voiceChips.get(i).setBackground(g);
        }
    }

    private void chooseVoice(int idx) {
        Prefs.put(this, "voice", idx);
        paintVoices();
        orbPreview.setColorAnimated(VoiceProfile.ALL[idx].color);
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            VoiceProfile vp = VoiceProfile.ALL[idx];
            startForegroundService(new Intent(this, JanuService.class).setAction(JanuService.A_REFRESH));
            startForegroundService(new Intent(this, JanuService.class).setAction(JanuService.A_SPEAK)
                    .putExtra("text", Prefs.hindi(this) ? vp.sampleHi : vp.sampleEn));
        } else {
            Toast.makeText(this, "आवाज़ सुनने के लिए पहले माइक की अनुमति दीजिए", Toast.LENGTH_SHORT).show();
        }
    }

    @Override protected void onPause() {
        saveAll();
        super.onPause();
    }

    // ------------------------------------------------------------------ save

    private void saveAll() {
        if (loading) return;
        Prefs.put(this, "key1", etKey1.getText().toString().trim());
        Prefs.put(this, "key2", etKey2.getText().toString().trim());
        Prefs.put(this, "c_url", etUrl.getText().toString().trim());
        Prefs.put(this, "c_key", etCKey.getText().toString().trim());
        Prefs.put(this, "c_model", etCModel.getText().toString().trim());
        int mi = spModel.getSelectedItemPosition();
        String model = mi == 2 ? etModel.getText().toString().trim() : MODEL_IDS[mi];
        Prefs.put(this, "model", model.isEmpty() ? MODEL_IDS[0] : model);
        Prefs.put(this, "lang", LANG_IDS[spLang.getSelectedItemPosition()]);
        Prefs.put(this, "wake", swWake.isChecked());
        if (JanuService.running) startService(new Intent(this, JanuService.class).setAction(JanuService.A_REFRESH));
    }

    // ------------------------------------------------------------------ verify

    private void verifyGemini(final int slot) {
        saveAll();
        final String key = Prefs.geminiKey(this, slot);
        final TextView out = slot == 1 ? tvV1 : tvV2;
        if (key.isEmpty()) { out.setText("Pehle key daaliye"); return; }
        out.setTextColor(Color.parseColor("#C9C9DD"));
        out.setText("Checking…");
        new Thread(() -> {
            AiClient.VerifyResult r = AiClient.verifyGemini(getApplicationContext(), key);
            if (r.ok) Prefs.markVerified(getApplicationContext(), "g" + slot, key, r.ms);
            runOnUiThread(() -> {
                if (slot == 1) err1 = r.ok ? null : r.msg; else err2 = r.ok ? null : r.msg;
                renderVerify();
            });
        }).start();
    }

    private void verifyCustom() {
        saveAll();
        final String url = Prefs.customUrl(this), key = Prefs.customKey(this), model = Prefs.customModel(this);
        if (key.isEmpty()) { tvVC.setText("Pehle key daaliye"); return; }
        tvVC.setTextColor(Color.parseColor("#C9C9DD"));
        tvVC.setText("Checking…");
        new Thread(() -> {
            AiClient.VerifyResult r = AiClient.verifyCustom(url, key, model);
            if (r.ok) Prefs.markVerified(getApplicationContext(), "custom", key, r.ms);
            runOnUiThread(() -> { errC = r.ok ? null : r.msg; renderVerify(); });
        }).start();
    }

    private void renderVerify() {
        paint(tvV1, "g1", Prefs.geminiKey(this, 1), err1);
        paint(tvV2, "g2", Prefs.geminiKey(this, 2), err2);
        paint(tvVC, "custom", Prefs.customKey(this), errC);
    }

    private void paint(TextView tv, String id, String secret, String err) {
        if (Prefs.isVerified(this, id, secret)) {
            tv.setTextColor(Color.parseColor("#7CFFB2"));
            tv.setText("✔ Verified • " + Prefs.verifiedMs(this, id) + " ms");
        } else if (err != null) {
            tv.setTextColor(Color.parseColor("#FF8FA3"));
            tv.setText("✘ " + err);
        } else {
            tv.setTextColor(Color.parseColor("#8F8FAE"));
            tv.setText(secret.isEmpty() ? "" : "Not verified");
        }
    }

    // ------------------------------------------------------------------ permissions

    private List<String> missingRuntime() {
        List<String> need = new ArrayList<>();
        List<String> all = new ArrayList<>();
        all.add(Manifest.permission.RECORD_AUDIO);
        if (Build.VERSION.SDK_INT >= 33) all.add(Manifest.permission.POST_NOTIFICATIONS);
        all.add(Manifest.permission.READ_CONTACTS);
        all.add(Manifest.permission.CALL_PHONE);
        for (String p : all) if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) need.add(p);
        return need;
    }

    @Override public void onRequestPermissionsResult(int c, String[] p, int[] r) {
        super.onRequestPermissionsResult(c, p, r);
        buildPermissions();
    }

    private boolean has(String p) { return checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED; }

    private boolean accessibilityOn() {
        String s = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (s == null) return false;
        ComponentName cn = new ComponentName(this, JanuAccessibilityService.class);
        return s.contains(cn.flattenToString()) || s.contains(cn.flattenToShortString());
    }

    private void buildPermissions() {
        permList.removeAllViews();
        row("Microphone", has(Manifest.permission.RECORD_AUDIO), () -> requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 1));
        if (Build.VERSION.SDK_INT >= 33)
            row("Notifications", has(Manifest.permission.POST_NOTIFICATIONS), () -> requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1));
        row("Contacts", has(Manifest.permission.READ_CONTACTS), () -> requestPermissions(new String[]{Manifest.permission.READ_CONTACTS}, 1));
        row("Phone calls", has(Manifest.permission.CALL_PHONE), () -> requestPermissions(new String[]{Manifest.permission.CALL_PHONE}, 1));
        row("Display over other apps", Settings.canDrawOverlays(this), () ->
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()))));
        row("Accessibility (app control)", accessibilityOn(), () -> {
            Toast.makeText(this, "Downloaded apps → Janu → ON", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
        });
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        row("Battery: unrestricted", pm != null && pm.isIgnoringBatteryOptimizations(getPackageName()), () -> {
            try {
                startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + getPackageName())));
            } catch (Exception e) {
                startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
            }
        });
    }

    private void row(String name, boolean ok, final Runnable action) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(0, dp(6), 0, dp(6));
        TextView n = new TextView(this);
        n.setText((ok ? "✅  " : "❌  ") + name);
        n.setTextColor(ok ? Color.parseColor("#C8FFE0") : Color.parseColor("#FFD6DE"));
        n.setTextSize(14);
        r.addView(n, new LinearLayout.LayoutParams(0, -2, 1f));
        if (!ok) {
            Button bt = new Button(this);
            bt.setText("Allow");
            bt.setTextColor(Color.WHITE);
            bt.setBackgroundResource(R.drawable.bg_btn);
            bt.setMinHeight(0); bt.setMinimumHeight(0);
            bt.setPadding(dp(16), dp(6), dp(16), dp(6));
            bt.setOnClickListener(v -> action.run());
            r.addView(bt, new LinearLayout.LayoutParams(-2, dp(36)));
        }
        permList.addView(r);
    }

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }
}
