package com.soumitra.janu;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import java.util.ArrayList;
import java.util.List;

public class DrawingView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final List<Path> paths = new ArrayList<>();
    private Path current;
    public DrawingView(Context c, AttributeSet a) { super(c, a); init(); }
    private void init() { paint.setColor(0xFF111111); paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(7f); paint.setStrokeCap(Paint.Cap.ROUND); paint.setStrokeJoin(Paint.Join.ROUND); setBackgroundColor(0xFFFFFFFF); }
    @Override protected void onDraw(Canvas c) { super.onDraw(c); for (Path p : paths) c.drawPath(p, paint); if (current != null) c.drawPath(current, paint); }
    @Override public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN: current = new Path(); current.moveTo(e.getX(), e.getY()); invalidate(); return true;
            case MotionEvent.ACTION_MOVE: if (current != null) { current.lineTo(e.getX(), e.getY()); invalidate(); } return true;
            case MotionEvent.ACTION_UP: if (current != null) { paths.add(current); current = null; invalidate(); } return true;
        }
        return true;
    }
    public void clear() { paths.clear(); current = null; invalidate(); }
    public void undo() { if (!paths.isEmpty()) { paths.remove(paths.size()-1); invalidate(); } }
}
