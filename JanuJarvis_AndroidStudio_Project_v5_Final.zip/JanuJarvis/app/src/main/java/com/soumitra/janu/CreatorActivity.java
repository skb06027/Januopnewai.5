package com.soumitra.janu;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/** Lightweight Creative Studio hub. AI generation remains API-driven; this screen is the native workspace entry point. */
public class CreatorActivity extends Activity {
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_creator);
        findViewById(R.id.btnDraw).setOnClickListener(v -> startActivity(new Intent(this, DrawingActivity.class)));
        findViewById(R.id.btnCode).setOnClickListener(v -> toast("Coding Studio ready — ask Janu to create or edit code."));
        findViewById(R.id.btnWebsite).setOnClickListener(v -> toast("Website Studio ready — ask Janu for a small website."));
        findViewById(R.id.btnVideo).setOnClickListener(v -> toast("Video Studio ready — describe the video you want."));
        findViewById(R.id.btnImage).setOnClickListener(v -> toast("Image Studio ready — describe the image you want."));
        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
    }
    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }
}
